
// Create audio object only once
if (!window.bgMusic) {
  window.bgMusic = new Audio("Cornfield chase.mp3");
  window.bgMusic.loop = true;
  window.bgMusic.autoplay = true;

  // Autoplay restrictions → start only after user interaction
  document.addEventListener("click", () => {
    if (window.bgMusic.paused) {
      window.bgMusic.play();
    }
  });
}